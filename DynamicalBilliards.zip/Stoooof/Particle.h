#include <iostream>
#include <cmath>
#include <string>
#include <iomanip>

class Particle {
	
	public:
		//Constructor and destructor, respectively.
		Particle();
		~Particle();
		
		double position[2];
		double direction[2];
		int numIterations;
		double lambda;
		double lambdaProv;
		int currLineNum;
		int currLineNumProv;
		
		//Methods.
		void createParticle();
		void reflect(Line* l);
		void findLambda(Line* l, int lineNum);
		void extrapolate();
		
};

Particle::Particle() {}
Particle::~Particle() {}

void Particle::createParticle() {
	
	//Initialises the particle's position and direction via user inputs.
	//Also asks for the number of iterations (collisions).
	
	using std::cout;
	using std::cin;
	using std::endl;
	
	cout << endl
		 << "Enter the particle's starting coordinates."
		 << endl
		 << "x: ";
	cin >> position[0];
	cout << "y: ";
	cin >> position[1];
	
	cout << endl
		 << "Enter the particle's initial direction vector."
		 << endl
		 << "x component: ";
	cin >> direction[0];
	cout << "y component: ";
	cin >> direction[1];
	
	cout << endl
		 << "Enter the number of collisions the particle should make\n"
		 << "before the program terminates: ";
	cin >> numIterations;
	
	currLineNum = -1;
	
}

void Particle::findLambda(Line* l, int lineNum) {
	
	//Calculates lambda for the intersection point on a line.
	//Extrapolates this to determine whether this point is part of the geometry or not.
	//If it is, lambda is reset.
	//The smallest positive value of lambda is taken.
	
	using std::cout;
	using std::endl;
	using std::setw;
	using std::right;
	using std::left;
	
	if (currLineNum != lineNum) {
		
		//cout << "currLineNum = " << currLineNum << "\t\tlineNum = " << lineNum << endl;
	
		double x0 = l -> x[0];
		double y0 = l -> y[0];
		double x1 = l -> x[1];
		double y1 = l -> y[1];
		double m_x = l -> m[0];
		double m_y = l -> m[1];
		
		//This is an algebraic expression that determines lambda.
		//Found from the intersection of two lines written in vector form.
		double numerator = ((position[1] - y0) * m_x) - ((position[0] - x0) * m_y);
		double denominator = (direction[0] * m_y) - (direction[1] * m_x);
		double testLambda = numerator / denominator;
		
		if (testLambda > 0) {
			
			double xNew = position[0] + (testLambda * direction[0]);
			bool withinRange;
			
			if (m_x > 0) withinRange = ((xNew <= x1) && (xNew >= x0)) ? true : false;
			else if (m_x < 0) withinRange = ((xNew < x0) && (xNew > x1)) ? true : false;
			else {
				double yNew = position[1] + (testLambda * direction[1]);
				if (m_y > 0) withinRange = ((yNew <= y1) && (yNew >= y0)) ? true : false;
				else if (m_y < 0) withinRange = ((yNew < y0) && (yNew > y1)) ? true : false;
			}
			
			if (withinRange == true && testLambda < lambdaProv) {
				lambdaProv = testLambda;
				lambda = lambdaProv;
				currLineNumProv = lineNum;
			}
			
		}
		
	}
	
}

void Particle::reflect(Line* l) {
	
	//Reflects the particle at a boundary.
	//The result is that the new direction vector is calculated.
	
	using std::cout;
	using std::endl;
	
	double dDotNormal = (direction[0] * (l -> normal[0]))
						+ (direction[1] * (l -> normal[1]));
	
	direction[0] = direction[0] - (2 * dDotNormal * (l -> normal[0]));
	direction[1] = direction[1] - (2 * dDotNormal * (l -> normal[1]));
	
}

void Particle::extrapolate() {
	
	//Extrapolates the particle's position based on lambda and position[0], position[1].
	
	position[0] = position[0] + (lambda * direction[0]);
	position[1] = position[1] + (lambda * direction[1]);
	
}


//Initialise current line number of particle as -1.
//The findLambda function will skip finding testLambda for the current line.
//It will calculate testLambda for each of the other lines.
//A series of checks will be carried out to ensure the intersection is valid
	//(lambda > 0, point of intersection is within the range of x values for the line).
//If not valid, no action is taken.
//If valid, lambda is set equal to testLambda.