//Attempt at general billiards geometries involving ellipses and straight lines.
//Matthew J. Metson
//First created: 24/6/2017
//Last edited: --/--/---- 

#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
#include <iomanip>
#include <limits>

#include "Line.h"
#include "Particle.h"

int main() {
	
	using std::cout;
	using std::cin;
	using std::endl;
	using std::right;
	using std::left;
	using std::setw;
	using std::setprecision;
	using std::ofstream;
	
	int x = 0;
	
	cout << endl << "How many lines would you like to add? ";
	cin >> x;
	
	const int numLines = x;
	Line lineArr[numLines];
	
	for (int i = 0; i < numLines; i++) {
		cout << endl << "Line " << (i+1) << ":";
		lineArr[i].createLine();
	}
	
	Particle ptcle;
	ptcle.createParticle();
	
	cout << endl << "Calculations in progress..." << endl;
	
	ofstream table;
	table.open("Table.txt");	

	table << right << setw(30) << "x"
		  << right << setw(30) << "y"
		  << endl
		  << right << setw(30) << setprecision(15) << ptcle.position[0]
		  << right << setw(30) << setprecision(15) << ptcle.position[1];
		 
	bool moreCollisions = true;
	int i = 0;
	
	while (i < ptcle.numIterations && moreCollisions == true) {
		ptcle.lambda = -1.;
		ptcle.lambdaProv = std::numeric_limits<double>::infinity();
		for (int j = 0; j < numLines; j++) ptcle.findLambda(&lineArr[j], j);
		if (ptcle.lambda < 0.) moreCollisions = false;
		else {
			ptcle.currLineNum = ptcle.currLineNumProv;
			ptcle.extrapolate();
			ptcle.reflect(&lineArr[ptcle.currLineNum]);
			table << endl
				  << right << setw(30) << setprecision(15) << ptcle.position[0]
				  << right << setw(30) << setprecision(15) << ptcle.position[1];
			i++;
		}
	}
	
	cout << "Calculations complete. Open \'Table.txt\' to view the results." << endl;
	table.close();
	
	return 0;
	
}