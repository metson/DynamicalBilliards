#include <iostream>
#include <cmath>
#include <string>
#include <iomanip>

class Line {
	
	public:
		//x ordinates and y ordinates for start and end of line.
		double x[2];
		double y[2];
	
		//Constructor and destructor, respectively.
		Line();
		~Line();
		
		//Gradient vector of line.
		double m[2];
				
		//Unit normal to line.
		double normal[2];
		
		//Methods.
		void createLine();
		
};

Line::Line() {}   //Blank constructor.
Line::~Line() {}  //Blank destructor.

void Line::createLine() {
	
	//Asks the user for the start/end points of a line.
	//The unit normal to the line is calculated.
	
	using std::cout;
	using std::cin;
	using std::endl;
	using std::sqrt;
	
	cout << endl
		 << "Enter the coordinates of the starting point of the line."
		 << endl
		 << "x: ";
		 
	cin >> x[0];
	
	cout << "y: ";
	
	cin >> y[0];
	
	cout << endl
		 << "Enter the coordinates of the end point of the line."
		 << endl
		 << "x: ";
		 
	cin >> x[1];
	
	cout << "y: ";
	
	cin >> y[1];
	
	cout << endl;
	
	m[0] = x[1] - x[0];
	m[1] = y[1] - y[0];
	
	double gradient = m[1] / m[0];
	
	if (m[1] == 0) {
		normal[0] = 0.;
		normal[1] = 1.;
	}
	
	else {
		double provNormal_x = 1.;
		double provNormal_y = -1. / gradient;
		
		double modulus = sqrt((provNormal_x * provNormal_x)
								+ (provNormal_y * provNormal_y));
								
		normal[0] = provNormal_x / modulus;
		normal[1] = provNormal_y / modulus;
	}
}